prepareRtt prunato a 2 (non so se fosse necessario ma sticazzi io l'ho fatto lo stesso e vaffanculo)
