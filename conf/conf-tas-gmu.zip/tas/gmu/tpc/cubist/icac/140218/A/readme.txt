prepareRtt -r 4
remoteGet -r 3

In this, I think I was avoiding to put in the training set samples relevant to rd 1 with 2 nodes
