Models built without any parameter
