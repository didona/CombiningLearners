Model built on all samples with 100K, without restrictions on the number of rules
