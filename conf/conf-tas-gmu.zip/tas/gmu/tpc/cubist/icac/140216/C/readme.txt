prepareRtt with -r 3; remoteGetRt with -r 2 (to avoid having lambda-dependent predicate om the branches)
