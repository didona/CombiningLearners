Models created with all samples with 100 K withouth limitations on the number of rules
